SPLUNK_HOST = "splunk-instance-host"
SPLUNK_PORT = 8089
SPLUNK_USERNAME = "admin"
SPLUNK_PASSWORD = "changeme"