import json
import os

SUCCESS_FLOW_FILE = "models/success_flow.json"

def compare_to_success_flow(logs):
    # Basic example: check steps order and error events
    events = [log.get("_raw", "") for log in logs]
    if not os.path.exists(SUCCESS_FLOW_FILE):
        return "No trained flow yet. Please input successful UUIDs first."
    with open(SUCCESS_FLOW_FILE) as f:
        success_flow = json.load(f)

    for i, step in enumerate(success_flow):
        if i >= len(events) or step not in events[i]:
            return f"Failure likely at step {i+1}: Expected '{step}' but got '{events[i]}'" if i < len(events) else "Flow ended prematurely."
    return "This UUID matches known successful flow."