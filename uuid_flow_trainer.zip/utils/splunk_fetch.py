from config import splunk_config
import splunklib.client as client
import splunklib.results as results

def fetch_logs_for_uuid(uuid):
    service = client.connect(
        host=splunk_config.SPLUNK_HOST,
        port=splunk_config.SPLUNK_PORT,
        username=splunk_config.SPLUNK_USERNAME,
        password=splunk_config.SPLUNK_PASSWORD
    )
    query = f'search index="main" uuid="{uuid}" | sort _time'
    job = service.jobs.create(query)
    while not job.is_done():
        pass
    result_stream = job.results(output_mode="json")
    return list(results.JSONResultsReader(result_stream))