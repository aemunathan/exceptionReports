from flask import Flask, request, jsonify, render_template
from utils.splunk_fetch import fetch_logs_for_uuid
from utils.flow_compare import compare_to_success_flow

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze_uuid():
    uuid = request.form.get("uuid")
    logs = fetch_logs_for_uuid(uuid)
    result = compare_to_success_flow(logs)
    return render_template("result.html", uuid=uuid, result=result)

if __name__ == "__main__":
    app.run(debug=True)