# UUID Flow Trainer

This project is designed to fetch logs from Splunk for a given UUID, compare it against trained success flows, and detect failure points. It also allows incremental training of successful and failed UUIDs to improve accuracy over time.

## Structure
- `frontend/`: Simple web interface to input UUIDs
- `backend/`: Flask-based backend to fetch logs, compare flows, and train the model
- `models/`: Stores success and failure flows
- `config/`: Configuration files including Splunk credentials
- `utils/`: Utility functions for log parsing and analysis

## Setup Instructions
1. Install dependencies: `pip install -r requirements.txt`
2. Update Splunk credentials in `config/splunk_config.py`
3. Run backend: `python backend/app.py`
4. Access frontend at `http://localhost:5000`