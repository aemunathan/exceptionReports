
import os
import re
import subprocess

BASE_DIR = os.path.expanduser("~/java-projects")
MODEL_NAME = "codellama"
LOG_FILE = os.path.join(BASE_DIR, "readme_generation_log.txt")

def run_ollama(prompt):
    try:
        result = subprocess.run(
            ["ollama", "run", MODEL_NAME],
            input=prompt.encode(),
            capture_output=True,
            timeout=60
        )
        return result.stdout.decode().strip()
    except Exception as e:
        return f"⚠️ AI Summary failed: {str(e)}"

def parse_pom(pom_path):
    try:
        from lxml import etree
        tree = etree.parse(pom_path)
        ns = {'m': 'http://maven.apache.org/POM/4.0.0'}
        artifact_id = tree.findtext("//m:artifactId", namespaces=ns)
        version = tree.findtext("//m:version", namespaces=ns)
        java_version = tree.findtext("//m:properties/m:java.version", namespaces=ns)
        return artifact_id or "Unknown", version or "Unknown", java_version or "Unknown"
    except Exception as e:
        return "Unknown", "Unknown", "Unknown"

def find_main_class(src_dir):
    for root, _, files in os.walk(src_dir):
        for file in files:
            if file.endswith(".java"):
                file_path = os.path.join(root, file)
                with open(file_path, errors="ignore") as f:
                    content = f.read()
                    if "public static void main" in content:
                        return file
    return "Not Found"

def get_code_snippets(src_dir, limit=3):
    snippets = []
    for root, _, files in os.walk(src_dir):
        for file in files:
            if file.endswith(".java"):
                with open(os.path.join(root, file), errors="ignore") as f:
                    snippets.append(f.read())
                    if len(snippets) >= limit:
                        return snippets
    return snippets

def update_repo(project_path):
    if os.path.exists(os.path.join(project_path, ".git")):
        subprocess.run(["git", "-C", project_path, "pull"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def log_message(message):
    with open(LOG_FILE, "a") as log_file:
        log_file.write(message + "\n")

def generate_readme(project_path):
    pom_path = os.path.join(project_path, "pom.xml")
    src_dir = os.path.join(project_path, "src")
    readme_path = os.path.join(project_path, "README.md")
    project_name = os.path.basename(project_path)

    update_repo(project_path)

    if os.path.exists(readme_path):
        log_message(f"Skipping {project_name}, README already exists.")
        return

    artifact_id, version, java_version = "Unknown", "Unknown", "Unknown"
    if os.path.exists(pom_path):
        artifact_id, version, java_version = parse_pom(pom_path)
        description = f"Auto-generated README for **{artifact_id}** using Maven metadata."
    else:
        code_samples = get_code_snippets(src_dir)
        if not code_samples:
            log_message(f"⚠️ No source found in {project_name}")
            return
        ai_prompt = (
            "This is a Java project. Summarize what this code does and what the project is likely about:\n\n"
            + "\n\n".join(code_samples[:2])
        )
        description = run_ollama(ai_prompt)
        artifact_id = project_name

    main_class = find_main_class(src_dir)
    structure = subprocess.getoutput(f"tree -L 2 {project_path} 2>/dev/null")

    content = f"""# {artifact_id}

## Description
{description}

## Build Tool
{"Maven" if os.path.exists(pom_path) else "Unknown"}

## Java Version
{java_version}

## Project Version
{version}

## Main Class
{main_class}

## Project Structure
```
{structure}
```

## How to Build
```bash
cd {artifact_id}
{"mvn clean install" if os.path.exists(pom_path) else "# no pom.xml — build manually"}
```

## How to Run
```bash
java -cp target/classes/ path.to.{main_class.split('.')[0]}  # Replace with actual path
```
"""
    with open(readme_path, "w") as f:
        f.write(content)
    log_message(f"✅ Generated README for {artifact_id}")

def main():
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
    for entry in os.scandir(BASE_DIR):
        if entry.is_dir():
            generate_readme(entry.path)

if __name__ == "__main__":
    main()
