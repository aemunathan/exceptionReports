import pandas as pd

def generate_first_occurrence(df: pd.DataFrame) -> pd.DataFrame:
    df_sorted = df.sort_values("date_hour")
    return (
        df_sorted.groupby(["app_id", "exception"], as_index=False)
        .first()[["date_hour", "app_id", "exception", "count"]]
        .sort_values(by="date_hour")
    )
