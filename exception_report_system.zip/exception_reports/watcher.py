import time
from pathlib import Path
from processor import process_file

WATCH_DIR = Path("input")

def watch_loop(interval_seconds=60):
    while True:
        for file in WATCH_DIR.glob("exceptions_*.csv"):
            process_file(file)
        time.sleep(interval_seconds)

if __name__ == "__main__":
    watch_loop()
