from flask import Flask, render_template, request
import pandas as pd
from pathlib import Path
from reports.first_occurrence import generate_first_occurrence

app = Flask(__name__)
DAILY_DIR = Path("../daily")

@app.route("/", methods=["GET", "POST"])
def index():
    report = None
    if request.method == "POST":
        date = request.form["date"]
        file_path = DAILY_DIR / f"exceptions_{date}.csv"
        if file_path.exists():
            df = pd.read_csv(file_path)
            df['date_hour'] = pd.to_datetime(df['date_hour'])
            report_df = generate_first_occurrence(df)
            report = report_df.to_html(classes="table table-striped", index=False)
    return render_template("index.html", report=report)

if __name__ == "__main__":
    app.run(debug=True)
