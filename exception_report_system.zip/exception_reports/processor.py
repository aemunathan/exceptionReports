import pandas as pd
from pathlib import Path
from datetime import datetime

PROCESSED_LOG = Path("processed_files.txt")
DAILY_DIR = Path("daily")
REPORTS_DIR = Path("reports")

def already_processed(file_path: Path) -> bool:
    if PROCESSED_LOG.exists():
        return file_path.name in PROCESSED_LOG.read_text().splitlines()
    return False

def mark_as_processed(file_path: Path):
    with open(PROCESSED_LOG, "a") as f:
        f.write(file_path.name + "\n")

def extract_date(file_path: Path) -> str:
    date_str = file_path.stem.split("_")[1][:8]
    return date_str

def process_file(file_path: Path):
    if already_processed(file_path):
        return

    df = pd.read_csv(file_path)
    df['date_hour'] = pd.to_datetime(df['date_hour'])
    day = extract_date(file_path)

    daily_file = DAILY_DIR / f"exceptions_{day}.csv"
    if daily_file.exists():
        df_existing = pd.read_csv(daily_file)
        df_combined = pd.concat([df_existing, df], ignore_index=True)
    else:
        df_combined = df

    df_combined.to_csv(daily_file, index=False)
    mark_as_processed(file_path)
