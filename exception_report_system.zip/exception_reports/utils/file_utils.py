import pandas as pd
from pathlib import Path

def save_report(df: pd.DataFrame, output_path: str, report_name: str):
    output_dir = Path(output_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_dir / f"{report_name}.csv", index=False)
